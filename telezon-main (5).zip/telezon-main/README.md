Jira Excel link: https://docs.google.com/spreadsheets/d/1VmarujH90MM5rqGOSzWjtppG1-LtYuZi0mZYm8TsQuU/edit?gid=0#gid=0



