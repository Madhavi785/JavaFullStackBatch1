package com.telezon.exception;

public class CustomPostpaidException extends RuntimeException {

    public CustomPostpaidException(String message) {
        super(message);
    }
}
