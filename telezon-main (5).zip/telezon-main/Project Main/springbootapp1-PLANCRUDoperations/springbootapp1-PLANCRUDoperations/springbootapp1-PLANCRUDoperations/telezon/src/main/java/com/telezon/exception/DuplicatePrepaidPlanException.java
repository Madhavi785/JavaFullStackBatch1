package com.telezon.exception;

public class DuplicatePrepaidPlanException extends RuntimeException{
	public DuplicatePrepaidPlanException(String message) {
		super(message);
	}

}
