package com.telezon.exception;

public class PrepaidPlanNotFoundException extends RuntimeException{
	public PrepaidPlanNotFoundException(String message) {
		super(message);
	}

}
